self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "cc70ec75e1cff11e659d",
    "url": "/static/js/main.cc70ec75.chunk.js"
  },
  {
    "revision": "02ba3405e7481ccc0a43",
    "url": "/static/js/1.02ba3405.chunk.js"
  },
  {
    "revision": "cc70ec75e1cff11e659d",
    "url": "/static/css/main.23876614.chunk.css"
  },
  {
    "revision": "4fd98ce06eaa033597ba9d54a635cdd8",
    "url": "/index.html"
  }
];